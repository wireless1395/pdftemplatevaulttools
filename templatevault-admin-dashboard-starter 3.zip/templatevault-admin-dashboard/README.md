# TemplateVault Tools Marketplace Starter

Responsive digital-products storefront plus an admin dashboard UI preview.

Start with `SETUP.md` for the storefront and `ADMIN-DASHBOARD-SETUP.md` for the dashboard preview.

**Important:** The admin UI is not secure or production-ready until Supabase authentication, server-side authorization, database policies, payment verification/webhooks, and private downloads are implemented. Do not accept real payments or use real customer data yet.
