# TemplateVault Tools Admin Dashboard

## What's included
- `admin.html`, `admin.css`, `admin.js`: responsive dashboard UI preview.
- The storefront starter files are included too.

## Important security status
This is a **front-end preview**, not a production administrator system. The preview login button is not authentication; product changes are not saved. Do not use it for real customer data or order management yet.

Before production, configure:
1. Supabase Auth for sign-in.
2. A server-verified administrator role (never trust a role stored only in browser JavaScript).
3. Row Level Security (RLS) policies for products, profiles, and orders.
4. Netlify environment variables for server-side secrets.
5. Payment webhooks and server-side payment verification for Paystack/Flutterwave.
6. Private object storage and time-limited signed download URLs.

## Deploy
Place these files at the repository root alongside `index.html`, `styles.css`, `app.js`, `netlify.toml`, and the `netlify/` folder. Commit changes to GitHub. Netlify will deploy the connected `main` branch.

Open `/admin.html` on the deployed site to view the dashboard preview.

Do not put passwords, service-role keys, or payment secret keys in GitHub or client-side JavaScript.
