const demoProducts = [
  {name:"Invoice & Receipt Pack", category:"Business templates", price:3000, status:"Draft"},
  {name:"Monthly Budget Planner", category:"Finance templates", price:2500, status:"Draft"},
  {name:"Business Forms Bundle", category:"Business templates", price:4500, status:"Draft"},
  {name:"Document Application Checklist", category:"Document guides", price:1500, status:"Draft"},
  {name:"ID Photo Sizing Guide", category:"Photo tools", price:1000, status:"Draft"},
  {name:"Sample Statement Layout", category:"Finance templates", price:2000, status:"Draft"}
];
const body = document.getElementById("products-body");
function renderProducts(){
  body.innerHTML = "";
  demoProducts.forEach((p, i) => {
    const tr = document.createElement("tr");
    [p.name,p.category,"₦"+p.price.toLocaleString("en-NG")].forEach(value => {
      const td=document.createElement("td"); td.textContent=value; tr.appendChild(td);
    });
    const status=document.createElement("td"); status.innerHTML='<span class="tag">Preview only</span>'; tr.appendChild(status);
    const action=document.createElement("td");
    const btn=document.createElement("button"); btn.className="mini-btn"; btn.type="button"; btn.textContent="Edit";
    btn.addEventListener("click",()=>alert("Product editing will be connected after secure database setup."));
    action.appendChild(btn); tr.appendChild(action); body.appendChild(tr);
  });
  document.getElementById("product-count").textContent=demoProducts.length;
}
document.getElementById("preview-login").addEventListener("click",()=>{
  document.getElementById("login-panel").hidden=true;
  document.getElementById("dashboard").hidden=false;
  renderProducts();
});
document.getElementById("sign-out").addEventListener("click",()=>{
  document.getElementById("dashboard").hidden=true;
  document.getElementById("login-panel").hidden=false;
});
document.getElementById("add-product").addEventListener("click",()=>alert("Adding products requires the secured database connection; this preview does not save changes."));
